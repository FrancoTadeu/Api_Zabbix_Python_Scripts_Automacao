# -*- coding: utf-8 -*-

#author: Franco Ferraciolli & Gabriel Moreira
  
import dotenv
import os
import csv
from pyzabbix import ZabbixAPI

dotenv.load_dotenv(dotenv.find_dotenv())
TOKEN = os.getenv("api_token")

zapi = ZabbixAPI("http://161.35.60.64")
zapi.login(api_token=TOKEN)

arq = csv.reader(open(r"C:\Users\Franco\Documents\TESTES API ZABBIX PYTHON\Tabelas_para_net_connect\triggers_consulta.csv"))

linhas = sum(1 for linha in arq)

f = csv.reader(open(r"C:\Users\Franco\Documents\TESTES API ZABBIX PYTHON\Tabelas_para_net_connect\triggers_consulta.csv"), delimiter=';')
i = 0

for [templatename,service,port,tagvalue1,tagvalue2,tagvalue3] in f:
    triggercriado = zapi.trigger.create(
        description = 'Connection to service - '+service+' Port ('+port+') failed',
        event_name = 'Connection to {HOST.CONN} service - '+service+' Port ('+port+') failed',
        expression = 'last(/'+templatename+'/net.tcp.service.perf[tcp,,'+port+'])=0',
        priority = 5, 
        recovery_mode = 0,
               tags = [{
            "tag": "integ_itsm_grp",
            "value":tagvalue1},
            {"tag": "integ_itsm_src",
            "value": tagvalue2},
            {"tag": "integ_itsm_type",
            "value": tagvalue3
            }],
        manual_close = 1     
    )
    print(triggercriado['triggerids'][0])