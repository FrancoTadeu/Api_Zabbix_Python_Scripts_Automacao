# -*- coding: utf-8 -*-

#author: Franco Ferraciolli & Gabriel Moreira
  
import dotenv
import os
import csv
from pyzabbix import ZabbixAPI

dotenv.load_dotenv(dotenv.find_dotenv())
TOKEN = os.getenv("api_token")

zapi = ZabbixAPI("http://161.35.60.64")
zapi.login(api_token=TOKEN)

arq = csv.reader(open(r"C:\Users\Franco\Documents\TESTES API ZABBIX PYTHON\Tabelas_para_net_connect\itens_consulta_porta.csv"))

linhas = sum(1 for linha in arq)

f = csv.reader(open(r"C:\Users\Franco\Documents\TESTES API ZABBIX PYTHON\Tabelas_para_net_connect\itens_consulta_porta.csv"), delimiter=';')
i = 0

for [hostname,porta,tpt_icmp_id,tagvalue,update,desc] in f:
    itemcriado = zapi.item.create(
        name = 'Net_Connect Serviço - Porta ('+porta+') '+hostname,
        key_ = 'net.tcp.service.perf[tcp,,'+porta+']',
        hostid = tpt_icmp_id,
        type = 3,
        value_type = 0,
        units = 'ms',
        tags = [{
            "tag": "tag_item_type",
            "value":tagvalue
            }],
        delay = update,
        description = desc     
    )
    #print('Net_Connect ICMP '+hostname +';'+ itemcriado['itemid'][0])
    print('Net_Connect ICMP '+hostname +';'+ itemcriado['itemids'][0])