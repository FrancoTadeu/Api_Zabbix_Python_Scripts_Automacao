from pyzabbix import ZabbixAPI

z = ZabbixAPI("http://161.35.60.64")
z.login("ageri.lab", "uubgg4G3Gshkp4s")

for g in z.trigger.get(output="extend", triggerids="23000" ):  
    print(g)
    