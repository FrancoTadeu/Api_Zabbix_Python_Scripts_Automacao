from pyzabbix import ZabbixAPI

zapi = ZabbixAPI("http://161.35.60.64")
zapi.login("ageri.lab", "uubgg4G3Gshkp4s")

#print("Connected to Zabbix API Version %s" % zapi.api_version())

for h in zapi.host.get(output="extend"):
   print(h['host']+';'+ h['hostid'])
