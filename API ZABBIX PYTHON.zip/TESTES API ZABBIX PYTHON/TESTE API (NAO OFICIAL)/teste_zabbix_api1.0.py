from pyzabbix import ZabbixAPI

#CRIAR ARRAY DE ACESSO
z = ZabbixAPI("http://161.35.60.64")
z.login("ageri.lab", "uubgg4G3Gshkp4s")

for h in z.host.get(output="extend"):
    print(h['hostid'])

# Get all disabled hosts
#print("Connected to Zabbix API Version %s" % z.api_version())


