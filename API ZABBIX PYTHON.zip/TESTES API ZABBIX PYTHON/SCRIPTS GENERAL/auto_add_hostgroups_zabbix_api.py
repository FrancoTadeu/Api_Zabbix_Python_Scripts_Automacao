#author: Franco Ferraciolli & Gabriel Moreira

from pyzabbix import ZabbixAPI

#CRIAR ARRAY DE ACESSO
z = ZabbixAPI("http://161.35.60.64")
z.login("ageri.lab", "uubgg4G3Gshkp4s")

#Especifica e cria o hostgroup

hgroups = [
        {'name':'URL_MONITORAMENTO'}, 
        ]
z.hostgroup.create(*hgroups)
