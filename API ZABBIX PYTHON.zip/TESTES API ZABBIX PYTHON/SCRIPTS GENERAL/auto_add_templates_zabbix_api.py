# -*- coding: utf-8 -*-

#author: Franco Ferraciolli & Gabriel Moreira
  
import dotenv
import os
import csv
from pyzabbix import ZabbixAPI

dotenv.load_dotenv(dotenv.find_dotenv())
TOKEN = os.getenv("api_token")

zapi = ZabbixAPI("http://161.35.60.64")
zapi.login(api_token=TOKEN)

arq = csv.reader(open(r"C:\Users\Franco\Documents\TESTES API ZABBIX PYTHON\Tabelas_para_net_connect\templates_consulta.csv"))

linhas = sum(1 for linha in arq)

f = csv.reader(open(r"C:\Users\Franco\Documents\TESTES API ZABBIX PYTHON\Tabelas_para_net_connect\templates_consulta.csv"), delimiter=';')
i = 0

for [tpt_name, tag_value_tpt] in f:
    templatecriado = zapi.template.create(
        host = 'tpt_netconnect_icmp'+tpt_name,
        groups = [{
            "groupid": "61"
        }],
        tags = [{
            "tag": "tag_tpt_pcp",
            "value":tag_value_tpt
        }],
    )
    print('tpt_netconnect_'+tpt_name +';'+ templatecriado['templateids'][0])
